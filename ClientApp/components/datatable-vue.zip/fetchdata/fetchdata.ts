import Vue from 'vue';
import { Component } from 'vue-property-decorator';

interface WeatherForecast {
    dateFormatted: string;
    temperatureC: number;
    temperatureF: number;
    summary: string;
}

@Component({
    components: {
        DataTableComponent: require('../datatable/datatable.vue.html')
    }
})
export default class FetchDataComponent extends Vue {
    forecasts: WeatherForecast[] = [];
    tableData: any = {
        options: {
            sortable: true,
            editable: true,
            pageCount: 10
        },

        columns: [
            {
                value: 'id',
                text: 'ID',
                sortable: true,
                editable: false
            },
            {
                value: 'name',
                text: 'Name',
                sortable: true,
                editable: true
            },
            {
                value: 'age',
                text: 'Age',
                sortable: true,
                editable: true
            },
            {
                value: 'sex',
                text: 'Sex',
                sortable: true,
                editable: true
            },
            {
                value: 'link',
                text: 'Link',
                sortable: false,
                editable: false,
                isHTML: true
            },
            {
                value: 'action',
                text: 'Action',
                sortable: false,
                editable: false,
                isButton: true
            }
        ],

        rows: [],

        onPageChanged(page: any) {
            console.log('Current page is ' + page);
        }
    }
    mounted() {
        fetch('api/SampleData/WeatherForecasts')
            .then(response => response.json() as Promise<WeatherForecast[]>)
            .then(data => {
                this.forecasts = data;
            });

        for (let i = 0; i < 50; i++) {
            const obj = {
                id: {
                    value: i + 1,
                },

                name: {
                    value: 'name' + i,
                    editable: i % 2 == 0 ? true : false
                },

                age: {
                    value: i,
                    editable: i % 2 == 0 ? true : false
                },

                sex: {
                    value: i % 2 == 0 ? 'Male' : 'Female',
                    editable: i % 2 == 0 ? true : false
                },

                link: {
                    value: `<a href="www.tech-coder.com">www.tech-coder.com</a>`
                },

                action: {
                    value: [
                        {
                            text: 'action1',
                            class: ['red'],
                            func: function (event: any, column: any, field: any) {
                                console.log('event', event);
                                console.log('column', column);
                                console.log('field', field);
                            }
                        },
                        {
                            text: 'action2',
                            class: ['green'],
                            func: function (event: any, column: any, field: any) {
                                console.log('event', event);
                                console.log('column', column);
                                console.log('field', field);
                            }
                        }
                    ]
                }
            }

            this.tableData.rows.push(obj);
        }
    }
}
